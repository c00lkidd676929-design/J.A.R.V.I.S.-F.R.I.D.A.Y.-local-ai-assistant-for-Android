package com.jarvisfriday.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

public class MainActivity extends Activity {
    private WebView web;
    private ExecutorService worker = Executors.newSingleThreadExecutor();
    private android.content.SharedPreferences prefs;
    private String selectedKind = "general";
    private static final int PICK_MODEL = 41;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff03131d);
        getWindow().setNavigationBarColor(0xff03131d);
        prefs = getSharedPreferences("local_models", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(0xff03131d);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private File modelDir() {
        File f = new File(getExternalFilesDir(null), "models");
        if (!f.exists()) f.mkdirs();
        return f;
    }
    private String pathFor(String kind) { return prefs.getString(kind + "_path", ""); }
    private String modelLabel(String kind) {
        String p = pathFor(kind);
        return p.isEmpty() ? "Not installed" : new File(p).getName();
    }
    private void setStatus(String message) {
        runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("JARVIS / FRIDAY").setMessage(message).setPositiveButton("OK", null).show());
    }
    private void showModels() {
        String[] items = {
            "General model: " + modelLabel("general"),
            "Coding model: " + modelLabel("coding"),
            "Download / replace GENERAL model",
            "Download / replace CODING model",
            "Import a GGUF file from this phone",
            "Load GENERAL model now",
            "Load CODING model now",
            "Unload current model"
        };
        new AlertDialog.Builder(this).setTitle("LOCAL GGUF MODEL MANAGER")
            .setItems(items, (d, which) -> {
                if (which == 2) downloadDialog("general");
                else if (which == 3) downloadDialog("coding");
                else if (which == 4) chooseModel();
                else if (which == 5) loadSelected("general");
                else if (which == 6) loadSelected("coding");
                else if (which == 7) worker.execute(() -> { NativeLlama.unload(); setStatus("Model unloaded."); });
                else if (which < 2) setStatus(items[which]);
            }).setNegativeButton("Close", null).show();
    }
    private void downloadDialog(String kind) {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(32, 16, 32, 4);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText url = new EditText(this);
        url.setSingleLine(false);
        url.setMinLines(2);
        url.setHint("Direct Hugging Face GGUF download URL");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        EditText filename = new EditText(this);
        filename.setHint(kind.equals("general") ? "qwen3-general.gguf" : "qwen3-coder.gguf");
        filename.setText(kind.equals("general") ? "general-model.gguf" : "coding-model.gguf");
        box.addView(url); box.addView(filename);
        new AlertDialog.Builder(this).setTitle("Download " + kind.toUpperCase() + " GGUF")
            .setMessage("Paste the direct file URL ending in .gguf. Large models may take a long time and need substantial free storage.")
            .setView(box)
            .setPositiveButton("Download", (d,w) -> startDownload(kind, url.getText().toString().trim(), filename.getText().toString().trim()))
            .setNegativeButton("Cancel", null).show();
    }
    private void startDownload(String kind, String url, String filename) {
        if (!url.startsWith("https://") || !url.toLowerCase().contains(".gguf")) {
            setStatus("Enter a direct HTTPS URL to a .gguf file (for example a Hugging Face resolve/main link).");
            return;
        }
        if (filename.isEmpty()) filename = kind + "-model.gguf";
        if (!filename.toLowerCase().endsWith(".gguf")) filename += ".gguf";
        final String name = filename.replaceAll("[^A-Za-z0-9._-]", "_");
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
        req.setTitle("Downloading " + name);
        req.setDescription("JARVIS / FRIDAY local model");
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        req.setDestinationInExternalFilesDir(this, "models", name);
        DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        long id = dm.enqueue(req);
        prefs.edit().putLong("download_" + id, id).putString("download_kind_" + id, kind).putString("download_name_" + id, name).apply();
        setStatus("Download started. Android will show its progress in notifications. After it finishes, open LOCAL AI MODELS and load the model.");
        registerReceiver(new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                long done = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (done != id) return;
                unregisterReceiver(this);
                DownloadManager.Query q = new DownloadManager.Query().setFilterById(id);
                try (android.database.Cursor cur = dm.query(q)) {
                    if (cur != null && cur.moveToFirst()) {
                        int status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            File f = new File(modelDir(), name);
                            prefs.edit().putString(kind + "_path", f.getAbsolutePath()).apply();
                            setStatus(name + " downloaded and registered as the " + kind + " model. Load it from LOCAL AI MODELS.");
                        } else setStatus("Download did not complete. Check the URL and available storage.");
                    }
                }
            }
        }, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), Context.RECEIVER_NOT_EXPORTED);
    }
    private void chooseModel() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-gguf"});
        selectedKind = "general";
        new AlertDialog.Builder(this).setTitle("Import as which model?")
            .setItems(new String[]{"General model", "Coding model"}, (d,w) -> {
                selectedKind = w == 0 ? "general" : "coding";
                startActivityForResult(i, PICK_MODEL);
            }).show();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_MODEL && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            prefs.edit().putString(selectedKind + "_path", uri.toString()).apply();
            setStatus("Model file selected. Load it from LOCAL AI MODELS.");
        }
    }
    private void loadSelected(String kind) {
        String p = pathFor(kind);
        if (p.isEmpty()) { setStatus("No " + kind + " model is registered. Download or import a GGUF first."); return; }
        worker.execute(() -> {
            String actual = p;
            if (p.startsWith("content://")) {
                try {
                    File copy = new File(modelDir(), kind + "-import.gguf");
                    try (InputStream in = getContentResolver().openInputStream(Uri.parse(p)); OutputStream out = new FileOutputStream(copy)) {
                        byte[] b = new byte[1024*1024]; int n; while ((n=in.read(b))>0) out.write(b,0,n);
                    }
                    actual = copy.getAbsolutePath();
                    prefs.edit().putString(kind + "_path", actual).apply();
                } catch (Exception e) { setStatus("Could not copy selected model: " + e.getMessage()); return; }
            }
            boolean ok = NativeLlama.load(actual);
            setStatus(ok ? kind.toUpperCase() + " model loaded. Only one model is kept loaded at a time." :
                "Model failed to load. It may be incompatible, incomplete, or too large for available memory.");
        });
    }
    private String route(String task) {
        String kind = "coding".equals(task) ? "coding" : "general";
        String path = pathFor(kind);
        if (path.isEmpty() && kind.equals("coding")) { kind = "general"; path = pathFor(kind); }
        return path;
    }
    private class Bridge {
        @JavascriptInterface public boolean isReady() { return true; }
        @JavascriptInterface public String status() {
            return "General: " + modelLabel("general") + " | Coding: " + modelLabel("coding");
        }
        @JavascriptInterface public void openModels() { runOnUiThread(() -> showModels()); }
        @JavascriptInterface public void generate(String system, String messagesJson, String task, String callbackId) {
            worker.execute(() -> {
                String error = null, answer = "";
                try {
                    String kind = "coding".equals(task) ? "coding" : "general";
                    String modelPath = route(kind);
                    if (modelPath.isEmpty()) throw new Exception("No " + kind + " GGUF is installed. Tap LOCAL AI MODELS to download or import one.");
                    if (!NativeLlama.load(resolvePath(modelPath))) throw new Exception("Could not load the " + kind + " model. Check model compatibility and available RAM.");
                    JSONArray messages = new JSONArray(messagesJson);
                    StringBuilder prompt = new StringBuilder();
                    prompt.append("<|im_start|>system\n").append(system).append("\n<|im_end|>\n");
                    for (int i=0;i<messages.length();i++) {
                        JSONObject m = messages.getJSONObject(i);
                        String role = m.optString("role", "user");
                        prompt.append("<|im_start|>").append(role).append("\n").append(m.optString("content")).append("\n<|im_end|>\n");
                    }
                    prompt.append("<|im_start|>assistant\n");
                    answer = NativeLlama.generate(prompt.toString(), 700);
                    if (answer.startsWith("ERROR:")) throw new Exception(answer);
                } catch (Throwable t) { error = t.getMessage() == null ? t.toString() : t.getMessage(); }
                final String a = answer, e = error;
                runOnUiThread(() -> {
                    String js = "window.__jarvisNativeDone(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(a) + "," + (e == null ? "null" : JSONObject.quote(e)) + ");";
                    web.evaluateJavascript(js, null);
                });
            });
        }
    }
    private String resolvePath(String path) { return path; }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        super.onDestroy();
        worker.execute(() -> NativeLlama.unload());
        worker.shutdown();
        if (web != null) web.destroy();
    }
}
