package com.jarvisfriday.app;

final class NativeLlama {
    static { System.loadLibrary("jarvisllama"); }
    static native boolean load(String path);
    static native void unload();
    static native String generate(String prompt, int maxTokens);
}
