#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <thread>
#include <android/log.h>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "JarvisLlama", __VA_ARGS__)

static std::mutex g_mutex;
static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static llama_sampler *g_sampler = nullptr;
static std::string g_loaded_path;

static void unload_locked() {
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_loaded_path.clear();
}
static bool load_locked(const std::string &path) {
    if (g_ctx && g_loaded_path == path) return true;
    unload_locked();
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) { LOGE("Could not load model: %s", path.c_str()); return false; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 4096;
    cp.n_batch = 512;
    cp.n_threads = std::max(2, (int)std::thread::hardware_concurrency() - 2);
    cp.n_threads_batch = cp.n_threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { unload_locked(); return false; }
    g_sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.65f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    g_loaded_path = path;
    return true;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jarvisfriday_app_NativeLlama_load(JNIEnv *env, jclass, jstring jpath) {
    const char *p = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);
    bool ok = load_locked(p ? p : "");
    env->ReleaseStringUTFChars(jpath, p);
    return ok ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_jarvisfriday_app_NativeLlama_unload(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_jarvisfriday_app_NativeLlama_generate(JNIEnv *env, jclass, jstring jprompt, jint max_tokens) {
    const char *p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt = p ? p : "";
    env->ReleaseStringUTFChars(jprompt, p);
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_ctx || !g_model) return env->NewStringUTF("ERROR: No GGUF model is loaded.");
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> tokens(prompt.size() + 512);
    int n = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), tokens.data(), (int)tokens.size(), true, true);
    if (n < 0) {
        tokens.resize((size_t)(-n));
        n = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), tokens.data(), (int)tokens.size(), true, true);
    }
    if (n <= 0) return env->NewStringUTF("ERROR: Prompt tokenization failed.");
    tokens.resize((size_t)n);
    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_sampler_reset(g_sampler);
    llama_batch batch = llama_batch_init((int)tokens.size(), 0, 1);
    for (int i = 0; i < (int)tokens.size(); ++i) {
        batch.token[i] = tokens[i];
        batch.pos[i] = i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == (int)tokens.size() - 1);
    }
    batch.n_tokens = (int)tokens.size();
    if (llama_decode(g_ctx, batch) != 0) {
        llama_batch_free(batch);
        return env->NewStringUTF("ERROR: Prompt is too long for the model context.");
    }
    std::string output;
    const int limit = std::max(1, std::min((int)max_tokens, 2048));
    for (int i = 0; i < limit; ++i) {
        llama_token tok = llama_sampler_sample(g_sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;
        char piece[512];
        int len = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, true);
        if (len > 0) output.append(piece, len);
        batch.n_tokens = 1;
        batch.token[0] = tok;
        batch.pos[0] = (llama_pos)tokens.size() + i;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = true;
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_batch_free(batch);
    return env->NewStringUTF(output.c_str());
}
